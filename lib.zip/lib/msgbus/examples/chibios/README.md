# ChibiOS examples

This directory contains examples to use with ChibiOS.
You should first clone it in this repository:

```bash
git clone https://github.com/cvra/ChibiOS.git
git checkout 3.0.1-cvra
```
