#ifndef _CMD_H_
#define _CMD_H_

#include <ch.h>

void shell_start(void);

#endif /* _CMD_H_ */
